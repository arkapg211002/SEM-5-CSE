#!/bin/bash
read -p "Enter directory name : " $directory
fullpath=$PWD$directory
if [ -d $fullpath ]; then
	echo "Directory exists"
else
	echo "Directory not present"
fi

