#!/bin/bash
if [ $(grep -c $1 /etc/passwd) -ne 0 ]; then
	echo "$1 is valid user"
else
	echo "$1 is invalid user"
fi

