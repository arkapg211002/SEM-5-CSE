#!/bin/bash
arr=(1 2 3 4)
echo ${arr[@]}
len=${#arr[@]}
echo $len
