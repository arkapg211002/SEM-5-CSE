#!/bin/bash
read -p "Enter the number of elemnts : " n
sum=0
arr=""
for (( i=0;i<n;i++ )) ; do
	read -p "Enter element $[ $i + 1 ] : " ele
	arr=$arr$ele" "
	sum=$[ $sum + $ele ]
done
echo "The sum of the elements $arr is : $sum"

