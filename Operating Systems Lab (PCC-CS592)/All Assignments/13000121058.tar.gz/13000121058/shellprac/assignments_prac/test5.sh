#!/bin/bash
read -p "Enter the year : " year
if echo $year | grep -qE "^[-+]?[0-9]+$" ; then
	if [ $year -lt 0 ]; then
		echo "$year is not valid year"
	else
		if [ $[ $year % 400 ] -eq 0 ];then
			echo "$year is leap year"
		elif [ $[ $year % 100 ] -ne 0 ] && [ $[ $year % 4 ] -eq 0 ]; then
			echo "$year is leap year"
		else 
			echo "$year is not leap year"
		fi
	fi
else
	echo "$year is invalid year"
fi

