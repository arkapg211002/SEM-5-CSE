# Sum of elements from command line

#!/bin/bash
sum=0
for var in "$@" ; do
	sum=$[ $sum + $var ]
done
echo "The sum of $@ is : $sum"

