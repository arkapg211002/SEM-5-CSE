#!/bin/bash
echo "The original array is : $@"
arr=($(echo "$@"))
len=$#
for ((i=0;i<len-1;i++)); do
	for ((j=0;j<len-i-1;j++));do
		in=$[ $j + 1 ]
		if [ ${arr[$j]} -gt ${arr[$in]} ];then
			temp=${arr[$j]}
			arr[$j]=${arr[$[ $j + 1 ]]}
			arr[$in]=$temp
		fi
	done
done
echo "The sorted array is : ${arr[@]}"

