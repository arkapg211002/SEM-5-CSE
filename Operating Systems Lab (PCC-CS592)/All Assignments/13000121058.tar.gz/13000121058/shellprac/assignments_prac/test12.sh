#!/bin/bash
arr=($(echo "$@"))
sum=0
for var in ${arr[@]}; do
	sum=$[ $sum + $var ]
done
echo "$sum"

