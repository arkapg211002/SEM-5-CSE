#!/bin/bash
#read -p "Enter the number of terms in fibonacci series : " n
n=$1
a=0
b=1
echo "The fibonacci series is as follows :"
echo -n "$a $b "
for (( i=2;i<n;i++ )); do
	c=$[ $a + $b ]
	echo -n "$c "
	a=$b
	b=$c
done
echo
