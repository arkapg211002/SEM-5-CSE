#!/bin/bash

# sum of digits
read -p "Enter the number : " n
a=$n
if (( n < 0 )) ; then
	n=$[ $n * -1 ]
fi
sum=0
while [ $n -gt 0 ]; do
	rem=$[ $n % 10 ]
	sum=$[ $sum + $rem ]
	n=$[ $n / 10 ]
done
echo "Sum of digits in $a is : $sum"


