#!/bin/bash
#returning array from function

echo "The original array is : $@"
arr=$(echo "$@")
square()
{
	local original=($(echo "$@"))
	local newarr=($(echo "$@"))
	local i=0
	for var in ${original[@]}; do
		newarr[$i]=$[ ${original[$i]} * ${original[$i]} ]
		i=$[ $i + 1 ]
	done
	echo ${newarr[@]}
}
result=($(square $arr))
echo "The result is : ${result[@]}"

