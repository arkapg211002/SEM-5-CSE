# Write a shell script to find the factorial of a given number

#!/bin/bash
#read -p "Enter the number : " n
p=1
n=$1
for (( i=1;i<=n;i++ )); do
	p=$[ $p * $i ]
done
echo "The factorial of $n is : $p"

