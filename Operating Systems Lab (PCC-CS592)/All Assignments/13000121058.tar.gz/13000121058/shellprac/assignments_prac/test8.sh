#!/bin/bash
read -p "Enter the number : " num

factorial()
{
	if [ $1 -eq 0 ] || [ $1 -eq 1 ]; then
		echo 1
	else
		local temp=$[ $1 - 1 ]
		local res=$(factorial $temp)
		echo $[ $res * $1 ]
	fi
}
echo "The factorial of $num is : $(factorial $num)"

