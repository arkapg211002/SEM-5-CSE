#!/bin/bash
echo $(echo "scale=2; l($1)/l(10)" | bc -l)
