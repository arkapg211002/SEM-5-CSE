#!/bin/bash
# passing array to function
echo "The original array is : $@"
arr=$(echo "$@")
sum()
{
	local s=0
	local myarr=($(echo "$@"))
	for val in ${myarr[@]}; do
		s=$[ $s + $val ]
	done
	echo "The sum of ${myarr[@]} is : $s"

}
echo "$(sum $arr)"

