#!/bin/bash
read -p "Enter the number of terms : " n
fib()
{
	if [ $1 -le 1 ];then
		echo -n "$1 "
	else
		echo -n "$[ $(fib $[ $1 - 1 ]) + $(fib $[ $1 - 2 ]) ] "
	fi
}
for (( i=0;i<n;i++)); do
	echo -n "$(fib $i) "
done
echo

