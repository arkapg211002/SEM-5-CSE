#!/bin/bash
echo "File name : $(basename $0)"
for var in "$1"; do
	echo -n "$var"
done
echo ""
