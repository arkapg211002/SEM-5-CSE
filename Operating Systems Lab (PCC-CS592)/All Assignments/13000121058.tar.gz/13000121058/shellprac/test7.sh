#!/bin/bash
for file in $PWD/* ; do
	if [ -d $file ]; then
		#echo "$file is a directory"
		lastfield=$(echo $file | rev | cut -d'/' -f1 | rev)
		echo "$lastfield is a directory"
	elif [ -f $file ]; then
		lastfield=$(echo $file | rev | cut -d'/' -f1 | rev)
		echo "$lastfield is normal file"
	else 
		echo "Nothing"
	fi
done 
