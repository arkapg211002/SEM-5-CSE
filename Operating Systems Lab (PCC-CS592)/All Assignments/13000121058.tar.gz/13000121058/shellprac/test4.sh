#!/bin/bash
read -p "Enter file name : " $file
fullpath=$PWD$file
if [ -e $fullpath ] && [ -w $fullpath ]; then
	echo "the file exist and is writable"
else
	echo "the file is either not present or not writable"
fi

