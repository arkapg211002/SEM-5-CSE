#!/bin/bash
read -p "Enter text : " text
echo "user input is : $text"
result=""
echo "Length of text ${#text}"
for ((i=0;i<${#text};i++));do
	ch=${text:i:1}
	if [ $[ $i % 2 ] -eq 0 ];then
		result+=$(echo $ch | tr [:lower:] [:upper:])
	else
		result+=$(echo $ch | tr [:upper:] [:lower:])
	fi
done
echo $result
