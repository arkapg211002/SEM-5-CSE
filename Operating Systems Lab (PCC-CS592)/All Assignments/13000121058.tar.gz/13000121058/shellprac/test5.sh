#!/bin/bash
case $USER in
	student | barbara)
		echo "welcome $USER"
		;;
	*)
		echo "Not allowed"
		;;
esac
