#!/bin/bash
testuser=hello
if [ $(grep -c $testuser /etc/passwd) -eq 0 ]; then
	echo "User present"
else
	echo "User not present"
fi

