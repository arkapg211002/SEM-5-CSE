#!/bin/bash
list="Alabama Alaska India china"
list=$list" Bhutan"
for country in $(cat states); do
	echo "$country"
done

