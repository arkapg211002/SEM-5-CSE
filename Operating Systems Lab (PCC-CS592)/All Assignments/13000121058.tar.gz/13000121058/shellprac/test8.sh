#!/bin/bash
IFS='
'
for entry in $(head -n 2 /etc/passwd); do
	echo "parts in $entry"
	IFS=:
	for part in $entry; do
		echo $part
	done
	echo -e "\n"
done
IFS=$IFSOLD




