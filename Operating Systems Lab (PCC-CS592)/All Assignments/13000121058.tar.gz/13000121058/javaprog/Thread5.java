import java.util.*;
import java.lang.*;
import java.io.*;

class Sum
{
	int sum;
	synchronized int sumarray(int a[])
	{
		sum=0;
		for(int i=0;i<a.length;i++)
		{
			sum+=a[i];
			System.out.println(Thread.currentThread().getName()+"Running");
			System.out.println("Added : "+a[i]);
			System.out.println("Sum :"+sum);
			try
			{
				Thread.sleep(10);
			}
			catch(InterruptedException e)
			{
				System.out.println("thread interrupted");
			}
		}
		return sum;
	}
}

class Mythread implements Runnable
{
	Thread t;
	int temp[],res;
	static Sum sa=new Sum();
	Mythread(String name,int nums[])
	{
		t=new Thread(this,name);
		temp=nums;
		t.start();
	}
	public void run()
	{
		System.out.println(t.getName()+" Starting");
		res=sa.sumarray(temp);
		System.out.println(t.getName()+" "+res);
		System.out.println(t.getName()+" Ending");
	}
}

class Thread5
{
	public static void main(String args[])
	{
		System.out.println("Main thread starting");
		int a[]={1,2,3,4,5};
		Mythread t1=new Mythread("C1",a);
		Mythread t2=new Mythread("C2",a);
		try
		{
			t1.t.join();
			System.out.println("C1 joined");
			t2.t.join();
			System.out.println("C2 joined");
		}
		catch(InterruptedException e)
		{
			System.out.println("Main thread interrupted");
		}
		System.out.println("Main thread ended");
	}
}
