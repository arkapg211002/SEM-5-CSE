import java.util.*;
import java.lang.*;
import java.io.*;

class Mythread implements Runnable
{
	Thread t;
	Mythread(String name)
	{
		t=new Thread(this,name);
		t.start();
	}
	public void run()
	{
		System.out.println(t.getName()+" Starting");
		for(int i=0;i<10;i++)
		{
			try
			{
				System.out.println(t.getName()+"["+i+"]");
				Thread.sleep(400);
			}
			catch(InterruptedException e)
			{
				System.out.println(t.getName()+" Interrupted");
			}
		}
		System.out.println(t.getName()+" ending");
	}
}

class Thread4
{
	public static void main(String args[])
	{
		System.out.println("Main Thread starting");
		Mythread t1=new Mythread("C1");
		Mythread t2=new Mythread("C2");
		Mythread t3=new Mythread("C3");
		String name;
		try
		{
			name=t1.t.getName();
			t1.t.join();
			System.out.println(name+" Joined");
			name=t2.t.getName();
			t2.t.join();
			System.out.println(name+" Joined");
			name=t3.t.getName();
			t3.t.join();
			System.out.println(name+" Joined");
		}
		catch(InterruptedException e)
		{
			System.out.println("Thread execution interrupted");
		}
		System.out.println("Main thread ending");
	}
}
