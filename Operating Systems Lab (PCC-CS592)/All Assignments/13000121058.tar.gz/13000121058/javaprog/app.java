import java.awt.*;
import java.applet.Applet;
/*
<Applet
code="app.class"
height="100"
width="150">
</Applet>
*/
public class app extends Applet
{
	public void paint(Graphics g)
	{
		g.drawString("Hello World!",30,30);
		System.out.println("Running java program\n");
		g.setColor(Color.red);
		g.fillRect(40,40,20,20);
		g.fillOval(70,70,20,20);
	}
}
