import java.util.*;
import java.lang.*;
import java.io.*;

class Mythread implements Runnable
{
	String tname;
	Mythread(String name)
	{
		tname=name;
	}
	public void run()
	{
		System.out.println(tname+" Starting ");
		try
		{
			for(int i=0;i<10;i++)
			{
				Thread.sleep(400);
				System.out.println(tname+"["+i+"]");
			}
		}
		catch(InterruptedException e)
		{
			System.out.println(tname+" Interrupted");
		}
		System.out.println("Terminating");
	}

}

class thread1
{
	public static void main(String args[])
	{
		Mythread mt=new Mythread("C1");
		Thread nt =new Thread(mt);
		nt.start();
		for(int i=10;i<50;i++)
		{
			System.out.println("M"+i);
			try
			{
				Thread.sleep(100);
			}
			catch(InterruptedException e)
			{
				System.out.println("Main thread interrupted");
			}
		}
		System.out.println("Main thread ending");
	}
}
