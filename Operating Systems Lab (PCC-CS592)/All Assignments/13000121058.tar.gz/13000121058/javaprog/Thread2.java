import java.util.*;
import java.io.*;
import java.lang.*;

class Mythread implements Runnable
{
	Thread t;
	Mythread(String name)
	{
		t=new Thread(this,name);
		t.start();
	}
	public void run()
	{
		System.out.println(t.getName()+" starting");
		for(int i=0;i<10;i++)
		{
			try
			{
				System.out.println(t.getName()+"["+i+"]");
				Thread.sleep(400);
			}
			catch(InterruptedException e)
			{
				System.out.println(t.getName()+"Interrupted");
			}
		}
		System.out.println(t.getName()+" ending");
	}
}

class Thread2
{
	public static void main(String args[])
	{
		System.out.println("Main thread starting");
		Mythread mt=new Mythread("C1");
		for(int i=10;i<50;i++)
		{
			try
			{
				System.out.println("M"+i);
				Thread.sleep(100);
			}
			catch(InterruptedException e)
			{
				System.out.println("main thread interrupted");
			}
		}
		System.out.println("Main thread ending");
	}
}
