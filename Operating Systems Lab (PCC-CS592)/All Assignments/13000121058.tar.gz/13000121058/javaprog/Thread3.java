import java.util.*;
import java.lang.*;
import java.io.*;

class Mythread extends Thread
{
	Mythread(String name)
	{
		super(name);
		start();
	}
	public void run()
	{
		System.out.println(getName()+" Starting");
		for(int i=0;i<5;i++)
		{
			try
			{
				System.out.println(getName()+"["+i+"]");
				Thread.sleep(400);
			}
			catch(InterruptedException e)
			{
				System.out.println(getName()+" interrupted");
			}
		}
		System.out.println(getName()+" ending");

	}
}

class Thread3
{
	public static void main(String args[])
	{
		Mythread mt=new Mythread("C1");
		System.out.println("Main thread starting");
		for(int i=10;i<20;i++)
		{
			System.out.println("M"+i);
			try
			{
				Thread.sleep(100);
			}
			catch(InterruptedException e)
			{
				System.out.println("main thread interrupted");
			}
		}
		System.out.println("Main thread ending");
	}
}
