#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

void *prime(void *input)
{
	int *x=input;
	int count=x[0];
	int start=x[1];
	int end=x[2];
	int i,c=0,j;
	printf("Inside thread %d\n",count);
	printf("Prime numbers from %d to %d are :\n",start,end);
	for(i=start;i<=end;i++)
	{
		if(i==1) continue;
		c=0;
		for(j=1;j<=i;j++)
		{
			if(i%j==0)c+=1;
		}
		if(c==2)printf("%d ",i);
	}
	printf("\n");
	pthread_exit(NULL);
}

void main()
{
	pthread_t t;
	int step,rem,start,end,n,i;
	int input[3];
	printf("Enter the value : ");
	scanf("%d",&n);
	step=n/10;
	rem=n%10;
	start=1;
	for(i=0;i<10;i++)
	{
		input[0]=i+1;
		end=start+step-1;
		input[1]=start;
		input[2]=end;
		if(i==9)
		{
			input[2]+=rem;
		}
		pthread_create(&t,NULL,prime,(void *)input);
		pthread_join(t,NULL);
		sleep(1);
		start+=step;
	}
}

