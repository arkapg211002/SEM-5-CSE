#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

void *custom(void *input)
{
	int in=*((int *)input);
	int c=0,i;
	if(in==1)pthread_exit("Neither prime nor composite");
	for(i=1;i<=in;i++)
	{
		if(in%i==0)c+=1;
	}
	if(c==2)pthread_exit("Prime");
	else pthread_exit("Not prime");
}

void main()
{
	pthread_t t;
	int n;
	void *res;
	printf("Enter the number : ");
	scanf("%d",&n);
	pthread_create(&t,NULL,custom,&n);
	pthread_join(t,&res);
	printf("%d is %s\n",n,(char *)res);
}
