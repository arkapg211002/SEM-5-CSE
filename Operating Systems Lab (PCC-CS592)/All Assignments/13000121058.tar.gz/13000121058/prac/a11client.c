#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<string.h>

typedef struct
{
	char res[100];
	int server_id;
	int client_id;
}shared;
shared *sd;

void custom(int signum)
{
	int item=signum;
}

void main()
{
	key_t key=ftok("memory",67);
	char input[100];
	int shmid=shmget(key,sizeof(shared),0666|IPC_CREAT);
	if(shmid==-1) printf("Cannot connect to shared memory\n");
	sd=(shared *)shmat(shmid,(void *)0,0);
	sd->client_id=getpid();
	signal(SIGCONT,custom);
	printf("Client Id : %d\n",sd->client_id);
	while(1)
	{
		printf("Enter the input : ");
		scanf("%[^\n]",input);
		getchar();
		if(strcmp(input,"exit")==0)
		{
			strcpy(sd->res,input);
			kill(sd->server_id,SIGCONT);
			break;
		}
		else
		{
			strcpy(sd->res,input);
			kill(sd->server_id,SIGCONT);
		}
		pause();
		printf("%s is %s\n",input,sd->res);
	}
	shmdt(sd);
}
