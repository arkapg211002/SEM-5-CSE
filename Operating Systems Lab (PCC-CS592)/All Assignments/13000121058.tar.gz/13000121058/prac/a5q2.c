#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void main()
{
	int pid=fork();
	if(pid==-1)
	{
		perror("fork");
		exit(1);
	}
	if(pid==0)
	{
		printf("Child process : %d %d\n",getpid(),getppid());
		sleep(10);
		printf("Orphan child process : %d %d \n",getpid(),getppid());
	}
	else
	{
		sleep(5);
		printf("Parent process : %d %d\n",getpid(),getppid());
	}
}
