#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<semaphore.h>
#include<time.h>

#define size 5

typedef struct
{
	int in;
	int out;
	int buffer[size];
	int res;
	int val;
	sem_t mutex;
	sem_t empty;
	sem_t full;
}sd;
sd *shared;

void main()
{
	key_t key=ftok("memory",67);
	int item;
	int shmid=shmget(key,sizeof(sd),0666|IPC_CREAT);
	if(shmid==-1) printf("Cannot create shared memory\n");
	shared=(sd *)shmat(shmid,(void *)0,0);
	shared->in=0;
	shared->out=0;
	srand(time(NULL));
	shared->val=rand();
	shared->res=0;
	sem_init(&shared->mutex,1,1);
	sem_init(&shared->empty,1,size);
	sem_init(&shared->full,1,0);
	while(shared->res==0)
	{
		sem_wait(&shared->empty);
		sem_wait(&shared->mutex);
		item=shared->val;
		printf("Producer adds %d at index %d\n",item,(shared->in));
		shared->buffer[shared->in]=item;
		shared->in=(shared->in + 1)%size;
		srand(time(NULL));
		shared->val=rand();
		sem_post(&shared->mutex);
		sleep(1);
		sem_post(&shared->full);
	}
	sem_destroy(&shared->mutex);
	sem_destroy(&shared->empty);
	sem_destroy(&shared->full);
	shmdt(shared);
	shmctl(shmid,IPC_RMID,NULL);
}
