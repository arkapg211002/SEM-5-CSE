#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<semaphore.h>
#include<pthread.h>
#include<time.h>
#include "buffer.h"

sem_t mutex;
sem_t empty;
sem_t full;

Buffer *b;

void *producer(void *arg)
{
	int item;
	while(1)
	{
		sem_wait(&empty);
		sem_wait(&mutex);
		srand(time(NULL));
		item=rand();
		printf("Producer added %d at index %d\n",item,(b->in));
		buffer_insert(b,item);
		sem_post(&mutex);
		sleep(1);
		sem_post(&full);
	}
	pthread_exit(NULL);
}

void *consumer(void *arg)
{
	int item,id;
	while(1)
	{
		sem_wait(&full);
		sem_wait(&mutex);
		id=(b->out);
		item=buffer_delete(b);
		printf("Consumer read %d at index %d\n",item,id);
		sem_post(&mutex);
		sleep(1);
		sem_post(&empty);
	}
	pthread_exit(NULL);
}

void main()
{
	pthread_t pt,ct;
	int n;
	printf("Enter the size of the buffer : ");
	scanf("%d",&n);
	b=buffer_init(b,n);
	sem_init(&mutex,0,1);
	sem_init(&empty,0,(b->size));
	sem_init(&full,0,0);
	pthread_create(&pt,NULL,producer,NULL);
	pthread_create(&ct,NULL,consumer,NULL);
	pthread_join(pt,NULL);
	pthread_join(ct,NULL);
	buffer_destroy(b);
	sem_destroy(&mutex);
	sem_destroy(&empty);
	sem_destroy(&full);
	printf("\n");
}
