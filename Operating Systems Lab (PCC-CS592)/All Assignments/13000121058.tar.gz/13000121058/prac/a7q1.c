#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<fcntl.h>

void custom(int signum)
{
	printf("\n Interrupted \n");
	printf("Signal Number : %d\n",signum);
	exit(0);
}

void main()
{
	signal(SIGINT,custom);
	while(1)
	{
		printf("Hello World\n");
		sleep(1);
	}
}
