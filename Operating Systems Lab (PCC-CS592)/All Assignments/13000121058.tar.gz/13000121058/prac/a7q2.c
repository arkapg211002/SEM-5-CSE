#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<fcntl.h>
#include<unistd.h>

int alarm_raised=0,sig;

void custom(int signum)
{
	alarm_raised=1;
	sig=signum;
}

void main()
{
	int pid=fork();
	if(pid==-1)
	{
		perror("fork");
		exit(1);
	}
	if(pid==0)
	{
		printf("Child process : %d %d \n",getpid(),getppid());
		sleep(5);
		kill(getppid(),SIGALRM);
		printf("Child process sent alarm to parent %d\n",getppid());
	}
	else
	{
		signal(SIGALRM,custom);
		printf("Parent process %d\n",getpid());
		while(alarm_raised==0)
		{
			printf("Inside Parent...\n");
			sleep(1);
		}
		wait(NULL);
		printf("Parent process received alarm\n");
		printf("Signal Number %d\n",sig);
	}
}
