#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<semaphore.h>
#include<signal.h>
#include<time.h>

typedef struct
{
	sem_t mutex;
	sem_t wrt;
	int val;
	int res;
}sd;
sd *shared;

void custom(int signum)
{
	shared->res=1;
	shmdt(shared);
	exit(0);
}

void main()
{
	key_t key=ftok("memory",67);
	int shmid=shmget(key,sizeof(sd),0666|IPC_CREAT);
	if(shmid==-1) printf("Cannot connect to shared mamory\n");
	shared=(sd *)shmat(shmid,(void *)0,0);
	signal(SIGINT,custom);
	while(1)
	{
		sleep(3);
		sem_wait(&shared->wrt);
		printf("Writer started\n");
		printf("original data %d\n",shared->val);
		srand(time(NULL));
		shared->val=rand();
		printf("Writer writes %d\n",shared->val);
		printf("Writer stopped\n");
		printf("\n");
		sleep(2);
		sem_post(&shared->wrt);
	}
}
