#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

int s=0;
void *custom(void *input)
{
	int in=*((int *)input);
	s=((in + 1)*in)/2;
	pthread_exit(&s);

}

void main()
{
	pthread_t t;
	int n;
	void *res;
	printf("Enter the number : ");
	scanf("%d",&n);
	pthread_create(&t,NULL,custom,&n);
	pthread_join(t,&res);
	printf("Sum of %d numbers is %d\n",n,*((int *)res));
}
