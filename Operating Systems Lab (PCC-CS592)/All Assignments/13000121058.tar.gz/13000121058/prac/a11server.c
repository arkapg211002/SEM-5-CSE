#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<signal.h>

typedef struct
{
	char res[100];
	int server_id;
	int client_id;
}shared;
shared *sd;

void custom(int signum)
{
	int in=signum;
}

void main()
{
	key_t key=ftok("memory",67);
	char input[100];
	int len,flag,i;
	int shmid=shmget(key,sizeof(shared),0666|IPC_CREAT);
	if(shmid==-1)
		printf("Cannot create shared memory\n");

	sd=(shared *)shmat(shmid,(void *)0,0);
	strcpy(sd->res,"\0");
	sd->server_id=getpid();
	sd->client_id=0;
	printf("Server id %d\n",sd->server_id);
	signal(SIGCONT,custom);
	while(1)
	{
		pause();
		flag=1;
		strcpy(input,sd->res);
		if(strcmp(input,"exit")==0)
			break;
		else
		{
			len=strlen(input);
			for(i=0;i<len/2;i++)
			{
				if(input[i]!=input[len-i-1])
				{
					strcpy(sd->res,"Not palindrome");
					flag=0;
					break;
				}

			}
			if(flag==1)
			{
				strcpy(sd->res,"palindrome");
			}
			printf("Server sent %s\n",sd->res);
			kill(sd->client_id,SIGCONT);
		}
	}
	shmdt(sd);
	shmctl(shmid,IPC_RMID,NULL);
}
