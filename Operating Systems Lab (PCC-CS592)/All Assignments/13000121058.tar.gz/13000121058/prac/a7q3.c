#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>

int received=0;
void custom(int signum)
{
	received=1;
}
void leap(int y)
{
	if(y%400==0) printf("Leap year");
	else if(y%100 !=0 && y%4==0) printf("Leap year");
	else printf("Not leap year");
}
void main()
{
	int pid=fork();
	int n,i=1;
	signal(SIGCHLD,custom);
	if(pid==0)
	{
		printf("Child Process %d %d\n",getpid(),getppid());
		while(1)
		{
			pause();
			if(received==1)
			{
				printf("Enter year : ");
				scanf("%d",&n);
				leap(n);
				received=0;
				printf("\n");
			}
		}
	}
	else
	{
		printf("parent process %d\n",getpid());
		while(i==1)
		{
			sleep(5);
			printf("Enter 1 to continue : ");
			scanf("%d",&i);
			if(i==0)continue;
			printf("Parent sending signal to child %d\n",pid);
			kill(pid,SIGCHLD);
		}
	}
}
