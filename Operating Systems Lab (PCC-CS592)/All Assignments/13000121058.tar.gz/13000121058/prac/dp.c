#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<semaphore.h>

//definitions
#define NUM_PHILOSOPHERS 5
#define THINKING 0
#define HUNGRY 1
#define EATING 2

//structure
typedef struct
{
	int state[NUM_PHILOSOPHERS];
	sem_t forks[NUM_PHILOSOPHERS];
	sem_t mutex;
}shared;

// initialize the shared memory
void shared_init(shared *sd)
{
	int i;
	for(i=0;i<NUM_PHILOSOPHERS;i++)
	{
		sd->state[i]=THINKING;
		sem_init(&sd->forks[i],1,1);
	}
	sem_init(&sd->mutex,1,1);
}

// pickup forks
void take_forks(shared *sd,int philosopher_num)
{
	int lf=philosopher_num;
	int rf=(philosopher_num + 1)%NUM_PHILOSOPHERS;

	sem_wait(&sd->mutex);
	sd->state[philosopher_num]=HUNGRY;
	printf("Philosopher % is hungry. Picked up forks %d and %d\n",philosopher_num,lf,rf);
	sem_post(&sd->mutex);

	sem_wait(&sd->forks[lf]);
	sem_wait(&sd->forks[rf]);
}

// put down forks
void put_forks(shared *sd,int philosopher_num)
{
	int lf=philosopher_num;
	int rf=(philosopher_num + 1)%NUM_PHILOSOPHERS;

	sem_wait(&sd->mutex);
	sd->state[philosopher_num]=THINKING;
	printf("Philosopher %d put down forks %d and %d\n",philosopher_num,lf,rf);
	sem_post(&sd->mutex);

	sem_post(&sd->forks[lf]);
	sem_post(&sd->forks[rf]);
}

// action on philosopher
void philosopher(shared *sd,int philosopher_num)
{
	int ln=(philosopher_num + NUM_PHILOSOPHERS -1)%NUM_PHILOSOPHERS;
	int rn=(philosopher_num + 1)%NUM_PHILOSOPHERS;

	while(1)
	{
		printf("Philosopher %d is thinking\n",philosopher_num);
		sleep(1);

		if((philosopher_num==0 && sd->state[rn]==THINKING && sd->state[ln]==THINKING) ||
		   (philosopher_num==1 && sd->state[rn]==THINKING && sd->state[ln]==THINKING) ||
		   (philosopher_num==2 && sd->state[rn]==THINKING && sd->state[ln]==THINKING) ||
		   (philosopher_num==3 && sd->state[rn]==THINKING && sd->state[ln]==THINKING) ||
		   (philosopher_num==4 && sd->state[rn]==THINKING && sd->state[ln]==THINKING))
		{
			take_forks(sd,philosopher_num);
			printf("Philosopher %d is eating\n",philosopher_num);
			sleep(2);
			put_forks(sd,philosopher_num);
		}
		else
		{
			printf("Philosopher %d is not eating\n",philosopher_num);
		}
	}
}

int main()
{
	int shmid,i;
	shared *sd;
	shmid=shmget(IPC_PRIVATE,sizeof(shared),0666|IPC_CREAT);
	if(shmid==-1) printf("Cannot create shared memory\n");
	sd=(shared *)shmat(shmid,(void *)0,0);
	shared_init(sd);

	// create philsopher processes
	for(i=0;i<NUM_PHILOSOPHERS;i++)
	{
		pid_t pid=fork();
		if(pid<0)
		{
			perror("fork");
			return 1;
		}
		if(pid==0)
		{
			philosopher(sd,i);
			return 0;
		}
	}

	// wait for the philsophers
	for(i=0;i<NUM_PHILOSOPHERS;i++)
	{
		wait(NULL);
	}

	shmdt(sd);
	shmctl(shmid,IPC_RMID,NULL);

}
