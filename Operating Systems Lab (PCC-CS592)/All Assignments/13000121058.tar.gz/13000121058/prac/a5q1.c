#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void main()
{
	int pid=fork();
	if(pid==-1)
	{
		perror("fork");
		exit(1);
	}
	if(pid==0)
	{
		sleep(5);
		printf("Child process : PID = %d , PPID = %d\n",getpid(),getppid());
	}
	else
	{
		sleep(5);
		printf("Parent Process : PID = %d , PPID = %d\n",getpid(),getppid());
	}
}
