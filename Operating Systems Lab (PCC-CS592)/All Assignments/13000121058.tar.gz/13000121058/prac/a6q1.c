#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/wait.h>

void main()
{
	int fd[2];
	char input[100],buffer[100];
	int len=0,n;
	pipe(fd);
	pid_t p=fork();
	if(p==0)
	{
		printf("Child %d %d\n",getpid(),getppid());
		printf("Enter input : ");
		scanf("%[^\n]",input);
		getchar();
		len=strlen(input);
		printf("Passing message to parent : %d\n",getppid());
		write(fd[1],input,len+1);

	}
	else
	{
		wait(NULL);
		printf("Parent %d %d\n",getpid(),getppid());
		n=read(fd[0],buffer,100);
		write(1,buffer,n);
		printf("\n");
	}
}
