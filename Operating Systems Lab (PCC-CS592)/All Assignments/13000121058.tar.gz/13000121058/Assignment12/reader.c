/*
Reader
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<semaphore.h>
#include<time.h>

void main()
{
	sem_t mutex,wrt;
	int readcount=0;
	key_t key=ftok("memory",67);
	int shmid=shmget(key,2048,0666|IPC_CREAT);
	srand(time(NULL));
	int *val=(int *)shmat(shmid,(void *)0,0);
	int i=1;
	*val=10;
	sem_init(&mutex,0,1);
	sem_init(&wrt,0,1);
	while(1)
	{
		sem_wait(&mutex);
		readcount++;
		if(readcount==1)
			sem_wait(&wrt);
		sem_post(&mutex);
		printf("Reader %d read value %d\n",i,*val);
		sem_wait(&mutex);
		readcount--;
		if(readcount==0)
			sem_post(&wrt);
		sem_post(&mutex);
		i+=1;
		sleep(2);
	}
	sem_destroy(&mutex);
	sem_destroy(&wrt);
	shmdt(val);
	shmctl(shmid,IPC_RMID,NULL);
}
