/*
Writer
*/

#include<stdio.h>
#include<stdlib.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<semaphore.h>
#include<time.h>
#include<unistd.h>

void main()
{
	sem_t wrt;
	key_t key=ftok("memory",67);
	int shmid=shmget(key,2048,0666|IPC_CREAT);
	int *val=(int *)shmat(shmid,(void *)0,0);
	int i=1;
	sem_init(&wrt,0,-1);
	*val=10;
	while(i<=5)
	{
		sleep(3);
		sem_wait(&wrt);
		printf("\nWriter %d started\n",i);
		printf("Original Value : %d\n",*val);
		srand(time(NULL));
		*val=rand();
		printf("New Value : %d",*val);
		i+=1;
		sleep(3);
		sem_post(&wrt);
	}
	sem_destroy(&wrt);
	shmdt(val);
}

