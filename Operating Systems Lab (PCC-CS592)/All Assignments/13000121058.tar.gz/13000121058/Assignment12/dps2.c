/*
Dining Philosophers problem
Philosopher 1 3
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/shm.h>
#include<sys/ipc.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<semaphore.h>
#include<signal.h>
#include<fcntl.h>

typedef struct
{
	sem_t chopstick[5];
	int id;
	int res;
}sd;
sd *shared;

void custom_handler(int signum)
{
	shared->res=0;
	exit(0);
}

void philosopher(int n)
{
	int count=n;
	printf("Philosopher %d wants to eat\n",count);
	printf("Philosopher %d tries to pick up the left chopstick\n",count);
	sem_wait(&shared->chopstick[count]);
	printf("Philosopher %d picks the left chopstick\n",count);
	printf("Philosopher %d tries to pick up the right chopstick\n",count);
	sem_wait(&shared->chopstick[(count+1)%5]);
	printf("Philosopher %d picks up the right chopstick\n",count);
	printf("Philosopher %d starts eating\n",count);
	sleep(2);
	printf("Philosopher %d finished eating\n",count);
	sem_post(&shared->chopstick[(count+1)%5]);
	printf("Philosopher %d leaves the right chopstick\n",count);
	sem_post(&shared->chopstick[count]);
	printf("Philosopher % d leaved the left chopstick\n",count);
}

void main()
{
	key_t key=ftok("memory",67);
	int shmid=shmget(key,sizeof(shared),0666|IPC_CREAT);
	signal(SIGINT,custom_handler);
	shared=(sd *)shmat(shmid,(void *)0,0);
	while(1)
	{
		if(shared->id%2!=0)
			philosopher(shared->id);
	}
}
