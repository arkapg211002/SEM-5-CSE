/*
Dining Philosopher using Shared Memory 
For Philosophers with even id
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<semaphore.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>

typedef struct
{
	sem_t chopstick[5];
	int id;
	int res;

}sd;
sd *shared;

void philosopher(int n)
{
	int count=n;
	printf("Philosopher %d wants to eat\n",count);
	printf("Philosopher %d tries to pick up the left chopstick\n",count);
	sem_wait(&shared->chopstick[count]);
	printf("Philosopher %d gets the left chopstick\n",count);
	printf("Philosopher %d tries to pick the right chopstick\n",count);
	sem_wait(&shared->chopstick[(count+1)%5]);
	printf("Philosopher %d gets the right chopstick\n",count);
	printf("Philosopher %d is eating\n",count);
	sleep(2);
	printf("Philosopher %d finished eating\n",count);
	sem_post(&shared->chopstick[(count+1)%5]);
	printf("Philosopher %d leaves the right chopstick\n",count);
	sem_post(&shared->chopstick[count]);
	printf("Philosopher %d leaves the left chopstick\n",count);
}

void main()
{
	key_t key=ftok("memory",67);
	int i;
	int shmid=shmget(key,sizeof(sd),0666|IPC_CREAT);
	shared=(sd *)shmat(shmid,(void *)0,0);
	for(i=0;i<5;i++)
		sem_init(&shared->chopstick[i],1,1);
	shared->id=0;
	shared->res=1;
	while(shared->res!=0)
	{
		if(shared->id%2==0)
			philosopher(shared->id);
		shared->id=(shared->id+1)%5;
		sleep(3);
	}
}
