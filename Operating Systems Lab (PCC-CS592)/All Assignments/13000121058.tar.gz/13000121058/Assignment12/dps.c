/*
Dining Philosopher using Shared Memory 
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<semaphore.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/wait.h>

typedef struct
{
	sem_t chopstick[5];
	int id;
}sd;
sd *shared;

void custom_handle(int signum)
{
	int i;
	for(i=0;i<5;i++)
		sem_destroy(&shared->chopstick[i]);
	exit(0);
}

void philosopher(int n)
{
	int count=n;
	do
	{
		sem_wait(&shared->chopstick[count]);
		printf("Philosopher %d gets left fork\n",count);
		sem_wait(&shared->chopstick[(count+1)%5]);
		printf("Philosopher %d gets right fork\n",count);
		printf("Philosopher %d eating ...\n",count);
		sleep(4);
		sem_post(&shared->chopstick[count]);
		printf("Philosopher %d puts down left fork\n",count);
		sem_post(&shared->chopstick[(count+1)%5]);
		printf("Philosopher %d puts down right fork\n",count);
		printf("Philosopher %d thinking ...\n",count);
		sleep(5);
	}while(1);
}

void main()
{
	key_t key=ftok("memory",67);
	int i;
	int shmid=shmget(key,sizeof(sd),0666|IPC_CREAT);
	shared=(sd *)shmat(shmid,(void *)0,0);
	for(i=0;i<5;i++)
		sem_init(&shared->chopstick[i],1,1);
	shared->id=0;
/*	for(i=0;i<5;i+=(i+1)%5)
	{
		pid_t pid=fork();
		if(pid==0)
		{
			philosopher(shared->id);
			shared->id=(shared->id+1)%5;
		}
	}
*/
	for(i=0;i<5;i++)
	{
		int pid=fork();
		if(pid==0)
		{
			philosopher(shared->id);
			
		}
		else
		{	
			shared->id=(shared->id+1)%5;
		}
	}
	for(i=0;i<5;i++)
		wait(NULL);
	
}
